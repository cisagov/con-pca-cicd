# Third-Party Libraries
from django.apps import AppConfig


class ApiConfig(AppConfig):
    name = "api"
